from .city import get_temperature, get_world_id
from .country import get_capital
