from countryinfo import CountryInfo

def get_capital(country):
    return CountryInfo(country).capital()